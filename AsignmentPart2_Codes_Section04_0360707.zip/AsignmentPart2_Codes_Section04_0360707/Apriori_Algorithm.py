import networkx as nx
import pandas as pd
import numpy as np
from apyori import apriori as ap
import matplotlib.pyplot as plt

# Setup for the viewing of the table in Pycharm
desired_width = 5000
pd.set_option('display.width', desired_width)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', None)
pd.set_option('display.max_rows', None)
np.set_printoptions(linewidth=desired_width)

# TODO: Apriori Algorithm

# Step 1: Load the dataset
AR_data = pd.read_excel('CleannedPartA.xlsx')

# Step 2: Verify the information of the loaded dataset
print("Sample of dataset:\n", AR_data.head(10))
print("Information of dataset:\n", AR_data.info())

# Step 3: Define the drug type column
drug_col = ['Heroin', 'Heroin_DC', 'Cocaine', 'Fentanyl', 'Ethanol', 'Fent_analogue', 'Oxycodone',
            'Oxymorphone', 'Hydrocodone', 'Benzodiazepine', 'Morph', 'Methadone',
            'Meth/Amphetamine', 'Amphet', 'Tramad', 'Hydromorphone', 'Xylazine', 'Gabapentin',
            'Opiate_NOS', 'Heroin/Morph/Codeine', 'Any_opioid', 'Other_opioid']

print("number of item", len(drug_col))

# Step 4: Manual encode the drug_col list
AR_data[drug_col] = AR_data[drug_col].map(lambda x: x in ['Y', 'P'])

# Step 5: Verify the column after manual encoding
print("\nAfter Encoding:\n", AR_data[drug_col].head(10))

# TODO 1: ---- Single-level Dementional Assocaition Rule
# Step 1: Create an empty List
substances = []

# Step 2: Append the drug usage of each individual in the list
for i in range(len(AR_data)):
    substance = [drug for drug in drug_col if AR_data.at[i, drug]]
    if substance:
        substances.append(substance)

# Step 3: Verify the items in substances
print(f"\nTotal Substances: {len(substances)}")
print(substances[:10])

# Step 4: Indentify the people with only one drug used
idx = []
for i in range(len(substances)):
    if len(substances[i]) < 2:
        idx.append(i)

# Step 5: Drop all the entries that are less than 2
RF_drug = AR_data.copy()
RF_drug.drop(idx, axis=0, inplace=True)
RF_drug.reset_index(drop=True, inplace=True)

print("\nTable after removing the entries that contain one or zero:\n", RF_drug[drug_col].head(10))

# Step 6: Redo step 2
s = []
for i in range(len(RF_drug)):
    sub = [drug for drug in drug_col if RF_drug.at[i, drug]]
    if sub:
        s.append(sub)

print(s[:5])
print("Total substances", len(s))

# Step 7: Determine minmum support level
num_rules = []
confidence_level = [0.2, 0.4, 0.6, 0.8, 1]
for conf in confidence_level:
    # ar_c = list(ap(s, min_support=0.001, min_confidence=conf, min_lift=3.5, min_length=2))
    ar_c = list(ap(s, min_support=0.005, min_confidence=conf, min_lift=3.5, min_length=2))
    # ar_c = list(ap(s, min_support=0.01, min_confidence=conf, min_lift=3.5, min_length=2))
    # ar_c = list(ap(s, min_support=0.05, min_confidence=conf, min_lift=3.5, min_length=2))
    num_rules.append(len(ar_c))

plt.figure(figsize=(10, 6))
plt.plot(confidence_level, num_rules, marker='o', linestyle='-', color='black')
plt.xlabel("Confidence")
plt.ylabel("Number of rules")
plt.title("Support Level (0.5%)")
plt.show()

# Step 8: Apply Apriori Algo
rd = dict({'Rule': [], 'Support': [], 'Confidence': [], 'Lift': []})
ar = ap(s, min_support=0.005, min_confidence=0.6, min_lift=3.5, min_length=2)
ar_results = list(ar)

# Step 9: Visualisation (in console)
for item in ar_results:
    pair = item[0]
    items = [x for x in pair]
    rd['Rule'].append(items[0] + " -> " + items[1])
    rd['Support'].append(item[1])
    rd['Confidence'].append(str(item[2][0][2]))
    rd['Lift'].append(str(item[2][0][3]))

# Step 10: Convert the data into data frame
df = pd.DataFrame(rd)

df.sort_values(by=['Confidence', 'Lift'], ascending=[False, False], inplace=True)
df.drop_duplicates(subset=['Confidence', 'Lift'], keep='first', inplace=True)
df.reset_index(drop=True, inplace=True)

# Print final association rules
print("Association Rule:\n", df)


# TODO 2: ---- Negative Association Rule
# Step 1: Define a function to calculate the negative support
def compute_neg_support(a, b, sub):
    # Calculate the positive support_a by using formula: number of A in itemset/length of the itemset
    supp_A = sum(a.issubset(set(i)) for i in sub) / len(sub)
    # Calculate the positive support_b by using formula: number of B in itemset/length of the itemset
    supp_B = sum(b.issubset(set(i)) for i in sub) / len(sub)
    # Calculate support(A->B) : count of A union B/ length of the itemsets
    supp_AB = sum(a.union(b).issubset(set(i)) for i in sub) / len(sub)
    # Calculate the support(~A) by using the formula: 1 - support(A)
    supp_nA = 1 - supp_A
    # Calculate the suport(~B) by using the formula: 1 - support(B)
    supp_nB = 1 - supp_B
    # Calculate the support(A union ~B): support(A) - support(A union B)
    supp_A_nB = supp_A - supp_AB
    # Calculate the support(~A union B): support(B) - support(B union A)
    supp_nA_B = supp_B - supp_AB

    return supp_A, supp_B, supp_AB, supp_nA, supp_nB, supp_A_nB, supp_nA_B


# Step 2: Define a function to calculate the negative association rule
def negative_rules(ar_results, sub, min_support, min_confidence):
    # create a list for storing negative rule
    neg_rules = []

    # loop through the item inside the ar_result and store it inside the pair list
    for item in ar_results:
        pair = item.items
        items = list(pair)

        # Skip the items that have the item less than 2
        if len(items) < 2:
            continue

        # store the first index inside the items to A and the second possition of items will be store in b
        A = {items[0]}
        B = {items[1]}

        # Call of function to compute the negative support
        (supp_A, supp_B, supp_AB, supp_nA, supp_nB, supp_A_nB,
         supp_nA_B) = compute_neg_support(A, B, sub)

        # Cormula for calculating the negative confidence
        conf_A_nB = supp_A_nB / supp_A if supp_A else 0
        conf_nA_B = supp_nA_B / supp_nA if supp_nA else 0

        # Formula for Calculating the conviction for each rule
        conv_A_nB = (1 - supp_B) / max(1 - conf_A_nB, 1e-10)
        conv_nA_B = (1 - supp_A) / max(1 - conf_nA_B, 1e-10)

        # if the confidence(A->~B) >= 0.7 and support(A -> ~B) >=0.005
        # the rule will be appended to neg_rules
        if conf_A_nB >= min_confidence and supp_A_nB >= min_support:
            neg_rules.append(
                {'Rule': f"{A} → NOT_{B}",
                 'Support': supp_A_nB,
                 'Confidence': conf_A_nB,
                 'Conviction': conv_A_nB
                 })

        if conf_nA_B >= min_confidence and supp_nA_B >= min_support:
            (neg_rules.append
             ({'Rule': f"NOT_{A} → {B}",
               'Support': supp_nA_B,
               'Confidence': conf_nA_B,
               'Conviction': conv_nA_B
               })
             )

    # return the neg_rules in a data frame format
    return pd.DataFrame(neg_rules)


# Step 3: call the negative_rules() function and assign the return data frame to nagetive_df
negative_df = negative_rules(ar_results, substances, 0.005, 0.7)


# Step 4: Display the result
negative_df.sort_values(by=["Confidence"], ascending=[False], inplace=True)
negative_df.drop_duplicates(subset=['Confidence', 'Conviction'], keep='first', inplace=True)
negative_df.reset_index(drop=True, inplace=True)
print("\nNegative Association Rules:\n", negative_df)

# TODO 2: ---- Multi-level Dementional Assocaition Rule
# Step 1: Defime a multi items list
m_items = []

# Step 2: store the items into the m_substances list
for i in range(len(AR_data)):
    gender = [str(AR_data.at[i, demo]) for demo in ['Sex']]
    city = [str(AR_data.at[i, city]) for city in ['Res_city']]
    sub = [drug for drug in drug_col if AR_data.at[i, drug]]

    if gender and city and sub:
        m_items.append(gender + city + sub)

# Step 3: Verify the m_items
print(f"Total Multi-Dimensional Itmes: {len(m_items)}")
print(m_items[:5])

# Step 4: Apply Apriori Algorithm
m_rd = {'Rule': [], 'Support': [], 'Confidence': [], 'Lift': []}
m_ar = ap(m_items, min_support=0.005, min_confidence=0.7, min_lift=1.5)

m_ar_results = list(m_ar)

# Step 5: Extract and Filter Rules
for item in m_ar_results:
    pair = item[0]
    items = list(pair)

    # Identify the antecedents and consequnt
    antecedent = [x for x in items if x in AR_data['Sex'].values or x in AR_data['Res_city'].values]
    consequent = [x for x in items if x in drug_col]

    # Ensure at least one demographic + one city in antecedent & at least one drug in consequent
    if len(antecedent) >= 2 and len(consequent) >= 1:
        rule = f"({', '.join(antecedent)})   -->   {', '.join(consequent)}"
        support = item[1]
        confidence = item[2][0][2]
        lift = item[2][0][3]

        m_rd['Rule'].append(rule)
        m_rd['Support'].append(support)
        m_rd['Confidence'].append(confidence)
        m_rd['Lift'].append(lift)

# Step 6: Convert to DataFrame
m_df = pd.DataFrame(m_rd)

# Step 7: Sort and Remove Duplicates
m_df.drop_duplicates(subset=['Confidence', 'Lift'], keep='first', inplace=True)
m_df.reset_index(drop=True, inplace=True)

# Step 8: Print Final Multi-Level Rules
print("\nFinal Rules:\n", m_df)

# TODO 4: ---- Visualisation

support = df['Support'].astype(float)
confidence = df['Confidence'].astype(float)
lift = df['Lift'].astype(float)

plt.figure(figsize=(10, 8))
scatter = plt.scatter(support, confidence, c=lift, cmap='Reds', alpha=0.6)

plt.xlabel('support')
plt.ylabel('confidence')
plt.title('Scatter plot for {} rules (Apriori Algorithm)'.format(len(df)))
cbar = plt.colorbar(scatter)
cbar.set_label('lift')
plt.grid(True)
plt.show()

# Network Graph Visualization
G = nx.Graph()

for drug in drug_col:
    G.add_node(drug)

for index, row in df.iterrows():
    rule = row['Rule'].split(" -> ")
    drug1 = rule[0]
    drug2 = rule[1]
    G.add_edge(drug1, drug2, lift=float(row['Lift']), support=float(row['Support']))

plt.figure(figsize=(12, 10))
pos = nx.kamada_kawai_layout(G)
node_sizes = [G.degree(node) * 50 for node in G.nodes()]
nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color='lightblue')
edges = G.edges()
edge_colors = [G[u][v]['lift'] for u, v in edges]
nx.draw_networkx_edges(G, pos, edge_color=edge_colors, edge_cmap=plt.cm.Reds, width=2)
nx.draw_networkx_labels(G, pos, font_size=7, bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))
sm = plt.cm.ScalarMappable(cmap=plt.cm.Reds, norm=plt.Normalize(vmin=min(edge_colors), vmax=max(edge_colors)))
sm.set_array([])
ax = plt.gca()
plt.colorbar(sm, label='Lift', ax=ax, shrink=0.8)

plt.title("Drug Association Network for Alriori Algorithm (Lift)")
plt.show()



