import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from mlxtend.frequent_patterns import association_rules as rulesmlx
from mlxtend.frequent_patterns import fpgrowth
from mlxtend.preprocessing import TransactionEncoder
import networkx as nx

# Setup for the viewing of the table in Pycharm
desired_width = 5000
pd.set_option('display.width', desired_width)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_colwidth', None)
pd.set_option('display.max_rows', None)
np.set_printoptions(linewidth=desired_width)

# TODO: ---- FP-GRWOTH ALGORITHM
# Step 1: Load dataset
fp_data = pd.read_excel('CleannedPartA.xlsx')

# Step 2: Define the drug column
drug_col = ['Heroin', 'Heroin_DC', 'Cocaine', 'Fentanyl', 'Ethanol', 'Fent_analogue', 'Oxycodone',
            'Oxymorphone', 'Hydrocodone', 'Benzodiazepine', 'Morph', 'Methadone', 'Meth/Amphetamine',
            'Amphet', 'Tramad', 'Hydromorphone', 'Xylazine', 'Gabapentin', 'Opiate_NOS',
            'Heroin/Morph/Codeine', 'Any_opioid', 'Other_opioid']

# Step 3: Manually encodes the data (True/False)
fp_data[drug_col] = fp_data[drug_col].map(lambda x: x == 'Y' or x == 'P')

# Step 4: Verifying the dataset after encoding
print("New Encoded Dataset:\n", fp_data[drug_col].head(10))
print("\nSize of Dataset: ", fp_data.shape)

# TODO 1: ---- Single-Level Demensional Association Rule
# Step 1: Identify the min_supp for fp-growth
num_rules = []
confidence_level = [0.2, 0.4, 0.6, 0.8, 1]

for conf in confidence_level:
    fp_c = fpgrowth(fp_data[drug_col], min_support=0.005, use_colnames=True)
    # fp_c = fpgrowth(fp_data[drug_col], min_support=0.01, use_colnames=True)
    # fp_c = fpgrowth(fp_data[drug_col], min_support=0.05, use_colnames=True)
    # fp_c = fpgrowth(fp_data[drug_col], min_support=0.10, use_colnames=True)
    rule = rulesmlx(fp_c, metric='confidence', min_threshold=conf)
    enhance_r = rule[rule['lift'] > 1]
    num_rules.append(len(enhance_r))

# Step 3: Visualise to display them
plt.figure(figsize=(10, 6))
plt.plot(confidence_level, num_rules, marker='o', linestyle='-', color='black')
plt.xlabel("Confidence")
plt.ylabel("Number of rules")
plt.title("Support Level (10%)")
plt.show()

# Step 1: Applying FP-Growth Algorithm (min_support = 0.05)
fp_res = fpgrowth(fp_data[drug_col], min_support=0.05, use_colnames=True)

# Step 2: Create different association rule from frequently occur items
rules = rulesmlx(fp_res, metric="confidence", min_threshold=0.6)

# Step 3: Strengthen the rules by setting the limit of lift
enhanced_rules = rules[rules['lift'] > 1].copy()
enhanced_rules.sort_values(by=['confidence'], ascending=[False], inplace=True)
enhanced_rules.reset_index(drop=True, inplace=True)

# Step 4: Display the overall result in the console
print("\nOverall Results with FP-Growth:\n",
      enhanced_rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])

# TODO 2: ---- Multi-Level Demensional Association Rule

# Step 1: Discretize the age into an age group
bins = [0, 12, 20, 30, 50, 100]
labels = ['Child', 'Adolescent', 'Young-Adult', 'Adult', 'Senior']
# Map the bins with respective labels
fp_data["Age_Group"] = pd.cut(fp_data["Age"], bins=bins, labels=labels, right=True)

# Step 2: Encode the features that are needed for multi-demensional association rule(Sex, Res_city)
# use TransactionEncoder to encode the features into binary form
te = TransactionEncoder()
df_out = fp_data[['Age_Group', 'Res_city']].astype(str).values.tolist()
te_ary = te.fit(df_out).transform(df_out)
# Cinvert into dataframe
df_encoded = pd.DataFrame(te_ary, columns=te.columns_)

# Step 4: concatenate the antecendents(Sex, Res_city) with consequents (drug_col)
df_final = pd.concat([df_encoded, fp_data[drug_col]], axis=1)

# Step 3: Verify the Encoding result
print("\nResult after Apply Transaction Encoding and Concatination:\n", df_final.head())

# Step 5: Apply fpgrowth
frequent_itemsets = fpgrowth(df_final, min_support=0.005, use_colnames=True)

# Step 6: Generate Association Rules
rules = rulesmlx(frequent_itemsets, metric="confidence", min_threshold=0.6)

# Step 7: Filter Rules where Antecedents contain only Age & City, and Consequents contain only Drug Types
age_city_cols = [col for col in df_encoded.columns]
fp_result = rules[
    rules['antecedents'].apply(lambda x: len(x) == 2 and all(item in age_city_cols for item in x)) &
    rules['consequents'].apply(lambda x: any(item in drug_col for item in x))
    ]

# Step 8: Further filter by Lift ≥ 1
fp_result = fp_result[fp_result['lift'] >= 1]
fp_result.sort_values(by=['confidence'], ascending=[False], inplace=True)
fp_result.reset_index(drop=True, inplace=True)

# Step 9: Display results
print("\n Result of Multi-level Association Rule (FP-Growth)\n",
      fp_result[['antecedents', 'consequents', 'support', 'confidence', 'lift']])

# TODO 3: ---- Visualisation
# Scatterplot
sup = enhanced_rules["support"].astype(float)
conf = enhanced_rules["confidence"].astype(float)
lift = enhanced_rules["lift"].astype(float)

plt.figure(figsize=(10, 8))
scatter = plt.scatter(sup, conf, c=lift, cmap='Reds', alpha=0.6)

plt.xlabel('Support')
plt.ylabel('Confidence')
plt.title('Scatter plot for {} rules (FP-Grwoth)'.format(len(enhanced_rules)))
plt.colorbar(scatter, label='lift')
plt.grid(True)
plt.show()

# Network Graph
G = nx.Graph()
for drug in drug_col:
    G.add_node(drug)

for index, row in enhanced_rules.iterrows():
    antecedents = list(row['antecedents'])
    consequents = list(row['consequents'])

    for drug1 in antecedents:
        for drug2 in consequents:
            G.add_edge(drug1, drug2, lift=float(row['lift']), support=float(row['support']))

plt.figure(figsize=(12, 10))
pos = nx.kamada_kawai_layout(G)

node_sizes = [G.degree(node) * 50 for node in G.nodes()]
nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color='lightblue')

edges = G.edges()
edge_colors = [G[u][v]['lift'] for u, v in edges]
nx.draw_networkx_edges(G, pos, edge_color=edge_colors, edge_cmap=plt.cm.Reds, width=2)
nx.draw_networkx_labels(G, pos, font_size=8, bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))
sm = plt.cm.ScalarMappable(cmap=plt.cm.Reds, norm=plt.Normalize(vmin=min(edge_colors), vmax=max(edge_colors)))
sm.set_array([])
ax = plt.gca()
plt.colorbar(sm, label='Lift', ax=ax, shrink=0.8)

plt.title("Drug Association Network for FP-Growth (Lift)")
plt.show()
